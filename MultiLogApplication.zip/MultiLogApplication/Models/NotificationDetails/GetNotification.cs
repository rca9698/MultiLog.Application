﻿namespace MultiLogApplication.Models.NotificationDetails
{
    public class GetNotification
    {
        public long UserId { get; set; }
        public long SessionUser { get; set; }
    }
}
