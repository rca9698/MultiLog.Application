﻿namespace MultiLogApplication.Models.NotificationDetails
{
    public class NotificationDetail
    {
        public long NotificationId { get; set; }
        public string NotificationDescription { get; set; }
    }
}
