﻿namespace MultiLogApplication.Models.NotificationDetails
{
    public class DeleteNotification
    {
        public long NotificationId { get; set; }
        public long SessionUser { get; set; }
    }
}
