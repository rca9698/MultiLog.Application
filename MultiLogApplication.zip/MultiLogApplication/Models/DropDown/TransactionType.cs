﻿namespace MultiLogApplication.Models.DropDown
{
    public class TransactionType
    {
        public long SessionUser { get; set; }
    }
}
