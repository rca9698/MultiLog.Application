﻿namespace MultiLogApplication.Models.DropDown
{
    public class GetStatusType
    {
        public long SessionUser { get; set; }
    }
}
