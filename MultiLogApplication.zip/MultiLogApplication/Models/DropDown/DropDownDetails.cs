﻿namespace MultiLogApplication.Models.DropDown
{
    public class DropDownDetails
    {
        public int DropDownId { get; set; }
        public string DropDownName { get; set; }
    }
}
