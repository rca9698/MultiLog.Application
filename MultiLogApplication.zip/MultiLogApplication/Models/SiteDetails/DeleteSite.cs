﻿namespace MultiLogApplication.Models.SiteDetails
{
    public class DeleteSite
    {
        public int SiteId { get; set; }
        public long SessionUser { get; set; }
    }
}
