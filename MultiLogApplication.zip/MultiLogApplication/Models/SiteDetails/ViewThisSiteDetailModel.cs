﻿namespace MultiLogApplication.Models.SiteDetails
{
    public class ViewThisSiteDetailModel
    {
        public long UserId { get; set; }
        public long SiteId { get; set; }
    }
}
