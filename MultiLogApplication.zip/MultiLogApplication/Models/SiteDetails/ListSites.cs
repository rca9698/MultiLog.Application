﻿namespace MultiLogApplication.Models.SiteDetails
{
    public class ListSites
    {
        public long SessionUser { get; set; }
    }
}
