﻿namespace MultiLogApplication.Models.Account
{
    public class GetAccounts
    {
        public long UserId { get; set; }
        public long SessionUser { get; set; }
    }
}
