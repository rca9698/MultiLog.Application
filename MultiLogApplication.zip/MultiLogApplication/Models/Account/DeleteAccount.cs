﻿namespace MultiLogApplication.Models.Account
{
    public class DeleteAccount
    {
        public long UserId { get; set; }
        public int SiteID { get; set; }
        public long SessionUser { get; set; }
    }
}
