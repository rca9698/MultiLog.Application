﻿namespace MultiLogApplication.Models.Account
{
    public class DeleteAccountRequest
    {
        public int AccountrequestId { get; set; }
        public long SessionUser { get; set; }
    }
}
