﻿namespace MultiLogApplication.Models.Passbook
{
    public class GetPassbookDetails
    {
        public long UserId { get; set; }
        public long SessionUser { get; set; }
    }
}
