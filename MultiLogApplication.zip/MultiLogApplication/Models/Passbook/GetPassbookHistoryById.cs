﻿namespace MultiLogApplication.Models.Passbook
{
    public class GetPassbookHistoryById
    {
        public string PassbookId { get; set; }
        public long SessionUser { get; set; }
    }
}
