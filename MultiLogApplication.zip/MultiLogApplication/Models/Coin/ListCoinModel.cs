﻿namespace MultiLogApplication.Models.Coin
{
    public class ListCoinModel
    {
        public int CoinType { get; set; }
        public long UserId { get; set; }
        public long SessionUser { get; set; }
    }
}
