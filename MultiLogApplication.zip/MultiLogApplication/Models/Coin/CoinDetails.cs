﻿namespace MultiLogApplication.Models.Coin
{
    public class CoinDetails
    {
        public long UserId { get; set; }
        public double Coin { get; set; }
        public string CoinType { get; set; }
    }
}
