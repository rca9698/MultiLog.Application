﻿namespace MultiLogApplication.Models.BankAccount
{
    public class DeleteAdminBankAccount
    {
        public long BankId { get; set; }
        public long SessionUser { get; set; }
    }
}
