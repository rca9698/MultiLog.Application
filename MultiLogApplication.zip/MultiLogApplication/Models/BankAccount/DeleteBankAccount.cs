﻿namespace MultiLogApplication.Models.BankAccount
{
    public class DeleteBankAccount
    {
        public long UserId { get; set; }
        public long BankId { get; set; }
        public long SessionUser { get; set; }
    }
}
