﻿namespace MultiLogApplication.Models.Common
{
    public enum ReturnStatus
    { 
        Failure = 0,
        Success = 1,
        RecordExists = 3
    }
}
