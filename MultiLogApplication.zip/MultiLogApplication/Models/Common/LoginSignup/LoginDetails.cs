﻿namespace MultiLogApplication.Models.Common.LoginSignup
{
    public class LoginDetails
    {
        public string UserNumber { get; set; }
        public string? OTP { get; set; }
        public string? Password { get; set; }
    }
}
