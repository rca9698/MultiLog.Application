﻿namespace MultiLogApplication.Models.User
{
    public class GetUsers
    {
        public long SessionUser { get; set; }
    }
}
