﻿namespace MultiLogApplication.Models.User
{
    public class DeleteUser
    {
        public long UserId { get; set; }
        public long SessionUser { get; set; }
    }
}
