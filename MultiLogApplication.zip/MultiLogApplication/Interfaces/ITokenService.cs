﻿namespace MultiLogApplication.Interfaces
{
    public interface ITokenService
    {
        public void SetToken(HttpClient client);
    }
}
